[08-Apr-2025 12:48:25 America/Bogota] PHP Fatal error:  Uncaught mysqli_sql_exception: Unknown column 'P.negocio_id' in 'SELECT' in /home/fundac77/domicilios.fundacionhuellas.com.co/API/Shop/productos/controller.php:38
Stack trace:
#0 /home/fundac77/domicilios.fundacionhuellas.com.co/API/Shop/productos/controller.php(38): mysqli->prepare()
#1 /home/fundac77/domicilios.fundacionhuellas.com.co/API/Shop/productos/controller.php(11): get()
#2 {main}
  thrown in /home/fundac77/domicilios.fundacionhuellas.com.co/API/Shop/productos/controller.php on line 38
[08-Apr-2025 12:48:35 America/Bogota] PHP Fatal error:  Uncaught mysqli_sql_exception: Unknown column 'P.negocio_id' in 'SELECT' in /home/fundac77/domicilios.fundacionhuellas.com.co/API/Shop/productos/controller.php:38
Stack trace:
#0 /home/fundac77/domicilios.fundacionhuellas.com.co/API/Shop/productos/controller.php(38): mysqli->prepare()
#1 /home/fundac77/domicilios.fundacionhuellas.com.co/API/Shop/productos/controller.php(11): get()
#2 {main}
  thrown in /home/fundac77/domicilios.fundacionhuellas.com.co/API/Shop/productos/controller.php on line 38
[08-Apr-2025 12:48:41 America/Bogota] PHP Fatal error:  Uncaught mysqli_sql_exception: Unknown column 'P.negocio_id' in 'SELECT' in /home/fundac77/domicilios.fundacionhuellas.com.co/API/Shop/productos/controller.php:38
Stack trace:
#0 /home/fundac77/domicilios.fundacionhuellas.com.co/API/Shop/productos/controller.php(38): mysqli->prepare()
#1 /home/fundac77/domicilios.fundacionhuellas.com.co/API/Shop/productos/controller.php(11): get()
#2 {main}
  thrown in /home/fundac77/domicilios.fundacionhuellas.com.co/API/Shop/productos/controller.php on line 38
[08-Apr-2025 12:49:09 America/Bogota] PHP Fatal error:  Uncaught mysqli_sql_exception: Unknown column 'P.negocio_id' in 'SELECT' in /home/fundac77/domicilios.fundacionhuellas.com.co/API/Shop/productos/controller.php:38
Stack trace:
#0 /home/fundac77/domicilios.fundacionhuellas.com.co/API/Shop/productos/controller.php(38): mysqli->prepare()
#1 /home/fundac77/domicilios.fundacionhuellas.com.co/API/Shop/productos/controller.php(11): get()
#2 {main}
  thrown in /home/fundac77/domicilios.fundacionhuellas.com.co/API/Shop/productos/controller.php on line 38
[08-Apr-2025 12:49:14 America/Bogota] PHP Fatal error:  Uncaught mysqli_sql_exception: Unknown column 'P.negocio_id' in 'SELECT' in /home/fundac77/domicilios.fundacionhuellas.com.co/API/Shop/productos/controller.php:38
Stack trace:
#0 /home/fundac77/domicilios.fundacionhuellas.com.co/API/Shop/productos/controller.php(38): mysqli->prepare()
#1 /home/fundac77/domicilios.fundacionhuellas.com.co/API/Shop/productos/controller.php(11): get()
#2 {main}
  thrown in /home/fundac77/domicilios.fundacionhuellas.com.co/API/Shop/productos/controller.php on line 38
[08-Apr-2025 12:51:01 America/Bogota] PHP Fatal error:  Uncaught mysqli_sql_exception: Unknown column 'P.negocio_id' in 'SELECT' in /home/fundac77/domicilios.fundacionhuellas.com.co/API/Shop/productos/controller.php:38
Stack trace:
#0 /home/fundac77/domicilios.fundacionhuellas.com.co/API/Shop/productos/controller.php(38): mysqli->prepare()
#1 /home/fundac77/domicilios.fundacionhuellas.com.co/API/Shop/productos/controller.php(11): get()
#2 {main}
  thrown in /home/fundac77/domicilios.fundacionhuellas.com.co/API/Shop/productos/controller.php on line 38
[08-Apr-2025 12:51:09 America/Bogota] PHP Fatal error:  Uncaught mysqli_sql_exception: Unknown column 'P.negocio_id' in 'SELECT' in /home/fundac77/domicilios.fundacionhuellas.com.co/API/Shop/productos/controller.php:38
Stack trace:
#0 /home/fundac77/domicilios.fundacionhuellas.com.co/API/Shop/productos/controller.php(38): mysqli->prepare()
#1 /home/fundac77/domicilios.fundacionhuellas.com.co/API/Shop/productos/controller.php(11): get()
#2 {main}
  thrown in /home/fundac77/domicilios.fundacionhuellas.com.co/API/Shop/productos/controller.php on line 38
[08-Apr-2025 12:51:20 America/Bogota] PHP Fatal error:  Uncaught mysqli_sql_exception: Unknown column 'P.negocio_id' in 'SELECT' in /home/fundac77/domicilios.fundacionhuellas.com.co/API/Shop/productos/controller.php:38
Stack trace:
#0 /home/fundac77/domicilios.fundacionhuellas.com.co/API/Shop/productos/controller.php(38): mysqli->prepare()
#1 /home/fundac77/domicilios.fundacionhuellas.com.co/API/Shop/productos/controller.php(11): get()
#2 {main}
  thrown in /home/fundac77/domicilios.fundacionhuellas.com.co/API/Shop/productos/controller.php on line 38
